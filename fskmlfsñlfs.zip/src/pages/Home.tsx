export default function Home() {
  return (
    <div>
      <h1>Home.</h1>
      <p>Página pública</p>
    </div>
  );
}